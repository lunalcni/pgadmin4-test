
Flask-Paranoid
--------------

Simple user session protection.


